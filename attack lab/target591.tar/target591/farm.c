/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_177()
{
    return 2428995912U;
}

void setval_129(unsigned *p)
{
    *p = 2428995912U;
}

void setval_485(unsigned *p)
{
    *p = 3347663530U;
}

unsigned getval_267()
{
    return 3351742792U;
}

unsigned addval_247(unsigned x)
{
    return x + 3281031512U;
}

unsigned getval_496()
{
    return 2425393240U;
}

unsigned getval_244()
{
    return 3281015002U;
}

void setval_323(unsigned *p)
{
    *p = 2425378909U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_316(unsigned x)
{
    return x + 3286270280U;
}

unsigned getval_361()
{
    return 3767093404U;
}

unsigned getval_467()
{
    return 2430634312U;
}

unsigned getval_159()
{
    return 3281046153U;
}

unsigned getval_461()
{
    return 3374891401U;
}

unsigned addval_479(unsigned x)
{
    return x + 2425542281U;
}

unsigned addval_184(unsigned x)
{
    return x + 3286272360U;
}

unsigned getval_115()
{
    return 2430634248U;
}

unsigned addval_123(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_480()
{
    return 3526940299U;
}

unsigned addval_441(unsigned x)
{
    return x + 3524840073U;
}

unsigned getval_213()
{
    return 79806857U;
}

void setval_446(unsigned *p)
{
    *p = 3375939993U;
}

unsigned addval_229(unsigned x)
{
    return x + 3523789197U;
}

unsigned addval_332(unsigned x)
{
    return x + 3525891721U;
}

unsigned addval_297(unsigned x)
{
    return x + 3524843145U;
}

unsigned addval_421(unsigned x)
{
    return x + 3224945033U;
}

unsigned addval_477(unsigned x)
{
    return x + 3374369417U;
}

unsigned getval_224()
{
    return 2425673353U;
}

unsigned addval_200(unsigned x)
{
    return x + 3376993929U;
}

unsigned addval_456(unsigned x)
{
    return x + 3682915977U;
}

unsigned getval_492()
{
    return 3398120831U;
}

void setval_268(unsigned *p)
{
    *p = 3372794249U;
}

unsigned getval_473()
{
    return 3767091238U;
}

unsigned getval_426()
{
    return 3372796569U;
}

unsigned getval_150()
{
    return 3374372489U;
}

unsigned getval_190()
{
    return 3234122377U;
}

unsigned getval_459()
{
    return 3526934953U;
}

unsigned addval_367(unsigned x)
{
    return x + 3682126473U;
}

unsigned getval_168()
{
    return 3232022921U;
}

unsigned getval_195()
{
    return 3527985801U;
}

unsigned addval_128(unsigned x)
{
    return x + 3286270280U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
